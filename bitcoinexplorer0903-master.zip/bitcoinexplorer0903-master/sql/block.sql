SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for block
-- ----------------------------
DROP TABLE IF EXISTS `block`;
CREATE TABLE `block`
(
  `id`             int NOT NULL auto_increment,
  `blockhash`      char(64),
  `height`         int,
  `time`           datetime,
  `tx_count`       int,
  `size_on_disk`   int,
  `difficulty`     double,
  `pre_blockhash`  char(64),
  `next_blockhash` char(64),
  PRIMARY KEY (`id`),
  unique `idx_blockhash` (`blockhash`),
  unique `idx_height` (`height`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf8;
