package io.cjf.bitcoinexplorer0903.service;

import org.springframework.scheduling.annotation.Async;

public interface BitcoinService {

//    @Async
    void fullImportData() throws InterruptedException;

}
