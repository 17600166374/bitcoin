package io.cjf.bitcoinexplorer0903.controller;

import com.alibaba.fastjson.JSONObject;
import io.cjf.bitcoinexplorer0903.api.BitcoinApi;
import io.cjf.bitcoinexplorer0903.dto.BlockRecentListDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/block")
public class BlockController {

    @Autowired
    private BitcoinApi bitcoinApi;

    @GetMapping("/getRecentBlock")
    public List<BlockRecentListDTO> getRecentBlock(){
        return null;
    }

    @GetMapping("/getBlockDetailByHash")
    public Object getBlockDetailByHash(@RequestParam String blockhash) throws Throwable {
        JSONObject result = bitcoinApi.getBlockDetailByHash(blockhash);
        return result;
    }

    @GetMapping("/getBlockDetailByHeight")
    public Object getBlockDetailByHeight(@RequestParam Integer height) throws Throwable {
        //todo get hash by height
        String blockhash = bitcoinApi.getBlockhashByHeight(height);

//        getBlockDetailByHash(null);
        return null;
    }
}
