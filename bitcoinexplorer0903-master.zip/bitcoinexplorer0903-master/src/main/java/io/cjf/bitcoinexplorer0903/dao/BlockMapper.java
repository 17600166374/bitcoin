package io.cjf.bitcoinexplorer0903.dao;

import io.cjf.bitcoinexplorer0903.po.Block;

public interface BlockMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Block record);

    int insertSelective(Block record);

    Block selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Block record);

    int updateByPrimaryKey(Block record);
}