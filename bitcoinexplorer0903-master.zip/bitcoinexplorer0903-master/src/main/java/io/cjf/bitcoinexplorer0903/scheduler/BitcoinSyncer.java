package io.cjf.bitcoinexplorer0903.scheduler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class BitcoinSyncer {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private Integer count = 0;

    @Scheduled(cron = "${sync.cron}")
    public void syncData(){
        count++;
        logger.info("count is {}", count);
        //todo sync the bitcoin data
    }
}
