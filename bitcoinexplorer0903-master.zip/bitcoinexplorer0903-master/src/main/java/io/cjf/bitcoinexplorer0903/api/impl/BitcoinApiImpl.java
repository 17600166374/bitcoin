package io.cjf.bitcoinexplorer0903.api.impl;

import com.alibaba.fastjson.JSONObject;
import com.googlecode.jsonrpc4j.JsonRpcHttpClient;
import io.cjf.bitcoinexplorer0903.api.BitcoinApi;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Base64;
import java.util.HashMap;

@Service
public class BitcoinApiImpl implements BitcoinApi {

    private JsonRpcHttpClient client;

    public BitcoinApiImpl(@Value("${jsonrpc.url}") String url,
                          @Value("${jsonrpc.user}") String user,
                          @Value("${jsonrpc.password}") String password) throws MalformedURLException {
        client = new JsonRpcHttpClient(new URL(url));
        HashMap<String, String> headers = new HashMap<>();
        String authStrOrig = String.format("%s:%s",user,password);
        String authStr = Base64.getEncoder().encodeToString(authStrOrig.getBytes());
        String authStrResult = String.format("Basic %s",authStr);
        headers.put("Authorization",authStrResult);
        client.setHeaders(headers);
    }

    @Override
    public JSONObject getBlockDetailByHash(String blockhash) throws Throwable {
        JSONObject result = client.invoke("getblock", new Object[]{blockhash}, JSONObject.class);
        return result;
    }

    @Override
    public String getBlockhashByHeight(Integer height) throws Throwable {
        String result = client.invoke("getblockhash", new Object[]{height}, String.class);
        return result;
    }
}
