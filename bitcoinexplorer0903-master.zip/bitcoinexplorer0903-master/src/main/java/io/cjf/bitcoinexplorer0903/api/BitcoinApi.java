package io.cjf.bitcoinexplorer0903.api;

import com.alibaba.fastjson.JSONObject;

public interface BitcoinApi {

    JSONObject getBlockDetailByHash(String blockhash) throws Throwable;

    String getBlockhashByHeight(Integer height) throws Throwable;
}
