package io.cjf.bitcoinexplorer0903.service.impl;

import io.cjf.bitcoinexplorer0903.service.BitcoinService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class BitcoinServiceImpl implements BitcoinService {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Async
    @Override
    public void fullImportData() throws InterruptedException {
        Thread.sleep(5000);
        logger.info("sync end");
    }
}
