package io.cjf.bitcoinexplorer0903.po;

import java.util.Date;

public class Block {
    private Integer id;

    private String blockhash;

    private Integer height;

    private Date time;

    private Integer txCount;

    private Integer sizeOnDisk;

    private Double difficulty;

    private String preBlockhash;

    private String nextBlockhash;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBlockhash() {
        return blockhash;
    }

    public void setBlockhash(String blockhash) {
        this.blockhash = blockhash == null ? null : blockhash.trim();
    }

    public Integer getHeight() {
        return height;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public Integer getTxCount() {
        return txCount;
    }

    public void setTxCount(Integer txCount) {
        this.txCount = txCount;
    }

    public Integer getSizeOnDisk() {
        return sizeOnDisk;
    }

    public void setSizeOnDisk(Integer sizeOnDisk) {
        this.sizeOnDisk = sizeOnDisk;
    }

    public Double getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(Double difficulty) {
        this.difficulty = difficulty;
    }

    public String getPreBlockhash() {
        return preBlockhash;
    }

    public void setPreBlockhash(String preBlockhash) {
        this.preBlockhash = preBlockhash == null ? null : preBlockhash.trim();
    }

    public String getNextBlockhash() {
        return nextBlockhash;
    }

    public void setNextBlockhash(String nextBlockhash) {
        this.nextBlockhash = nextBlockhash == null ? null : nextBlockhash.trim();
    }
}