package io.cjf.bitcoinexplorer0903.controller;

import io.cjf.bitcoinexplorer0903.service.BitcoinService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/test")
public class TestController {

    @Autowired
    private BitcoinService bitcoinService;

    @GetMapping("/hello")
    public String hello(HttpServletRequest request){
        return null;
    }

    @GetMapping("/fullImportData")
    public void fullImportData() throws InterruptedException {
        bitcoinService.fullImportData();
    }
}
